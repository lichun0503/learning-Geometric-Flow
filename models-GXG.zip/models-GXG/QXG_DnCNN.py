"""
phi(s)= paplacian**3(kappa)
"""
import sys

sys.path.insert(0, '../../Utils')

import torch
import torch.nn as nn
import numpy as np
import time
import random
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import matplotlib as mpl
import scipy.io


# from plotting import newfig, savefig

def gradients(outputs, inputs):
    return torch.autograd.grad(outputs, inputs, grad_outputs=torch.ones_like(outputs),
                               create_graph=True)


def to_numpy(input):
    if isinstance(input, torch.Tensor):
        return input.detach().cpu().numpy()
    elif isinstance(input, np.ndarray):
        return input
    else:
        raise TypeError('Unknown type of input, expected torch.Tensor or ' \
                        'np.ndarray, but got {}'.format(type(input)))


def figsize(scale, nplots=1):
    fig_width_pt = 390.0  # Get this from LaTeX using \the\textwidth
    inches_per_pt = 1.0 / 72.27  # Convert pt to inch
    golden_mean = (np.sqrt(5.0) - 1.0) / 2.0  # Aesthetic ratio (you could change this)
    fig_width = fig_width_pt * inches_per_pt * scale  # width in inches
    fig_height = nplots * fig_width * golden_mean  # height in inches
    fig_size = [fig_width, fig_height]
    return fig_size


pgf_with_latex = {  # setup matplotlib to use latex for output
    "pgf.texsystem": "pdflatex",  # change this if using xetex or lautex
    "text.usetex": True,  # use LaTeX to write all text
    "font.family": "serif",
    "font.serif": [],  # blank entries should cause plots to inherit fonts from the document
    "font.sans-serif": [],
    "font.monospace": [],
    "axes.labelsize": 10,  # LaTeX default is 10pt font.
    "font.size": 10,
    "legend.fontsize": 8,  # Make the legend/label fonts a little smaller
    "xtick.labelsize": 8,
    "ytick.labelsize": 8,
    "figure.figsize": figsize(1.0),  # default fig size of 0.9 textwidth
    "pgf.preamble": [
        r"\usepackage[utf8x]{inputenc}",  # use utf8 fonts becasue your computer can handle it :)
        r"\usepackage[T1]{fontenc}",  # plots will be generated using this preamble
    ]
}
mpl.rcParams.update(pgf_with_latex)

import matplotlib.pyplot as plt


# I make my own newfig and savefig functions
def newfig(width, nplots=1):
    fig = plt.figure(figsize=figsize(width, nplots))
    ax = fig.add_subplot(111)
    return fig, ax


def savefig(filename, crop=True):
    if crop == True:
        #        plt.savefig('{}.pgf'.format(filename), bbox_inches='tight', pad_inches=0)
        plt.savefig('{}.pdf'.format(filename), bbox_inches='tight', pad_inches=0)
        plt.savefig('{}.eps'.format(filename), bbox_inches='tight', pad_inches=0)
    else:
        #        plt.savefig('{}.pgf'.format(filename))
        plt.savefig('{}.pdf'.format(filename))
        plt.savefig('{}.eps'.format(filename))


torch.manual_seed(123456)
np.random.seed(123456)
alph = 0.5
eta = 0.1
lmd = 0.01
gemma = 0.01
rho = 1
mu = 0.01

H_o = 0.1
k = 6 * np.pi


class PRE(nn.Module):
    def __init__(self):
        super(PRE, self).__init__()

    def forward(self, x):
        x = x.unsqueeze(dim=1)
        x = x.permute(0, 2, 1)
        return x


class DnCNN(nn.Module):
    def __init__(self, channels, num_of_layers=2):
        super(DnCNN, self).__init__()
        kernel_size = 3
        padding = 1
        features = 64
        layers = []
        layers.append(PRE())
        layers.append(nn.Conv1d(in_channels=channels, out_channels=features, kernel_size=kernel_size, padding=padding, bias=False))
        layers.append(nn.ReLU(inplace=True))
        for _ in range(num_of_layers-2):
            layers.append(nn.Conv1d(in_channels=features, out_channels=features, kernel_size=kernel_size, padding=padding, bias=False))
            layers.append(nn.BatchNorm1d(features))
            layers.append(nn.ReLU(inplace=True))
        layers.append(nn.Conv1d(in_channels=features, out_channels=4, kernel_size=kernel_size, padding=padding, bias=False))
        self.net = nn.Sequential(*layers)
    def forward(self, x):
        out = self.net(x)
        return out

    def loss_pde(self, x):
        y = self.net(x)
        u = y[:, 0]
        u_g = gradients(u, x)[0]
        u_t, u_x, u_y = u_g[:, 0], u_g[:, 1], u_g[:, 2]
        u_xx, u_xy, u_yy = gradients(u_x, x)[0][:, 1], gradients(u_x, x)[0][:, 2], gradients(u_y, x)[0][:, 2]

        kappa = (u_xx*(1+u_y**2)+u_yy*(1+u_x**2)-2*u_x*u_y*u_xy)/(1+u_x**2 + u_y**2)**(3/2)

        kappa_g = gradients(kappa, x)[0]
        kappa_t, kappa_x, kappa_y = kappa_g[:, 0], kappa_g[:, 1], kappa_g[:, 2]
        kappa_xx, kappa_xy, kappa_yy = gradients(kappa_x, x)[0][:, 1],\
                                       gradients(kappa_x, x)[0][:,2], gradients(kappa_y, x)[0][:, 2]
        kappa_Laplacian = (kappa_xx*(1+kappa_y**2)+kappa_yy*(1+kappa_x**2)-2*kappa_x*kappa_y*kappa_xy)/(1+kappa_x**2 + kappa_y**2)**(3/2)

        Q = kappa_Laplacian

        Q_g = gradients(Q, x)[0]
        Q_t, Q_x, Q_y = Q_g[:, 0], Q_g[:, 1], Q_g[:, 2]
        Q_xx, Q_xy, Q_yy = gradients(Q_x, x)[0][:, 1], \
                                       gradients(Q_x, x)[0][:, 2], gradients(Q_y, x)[0][:, 2]

        Q_Laplacian = (Q_xx*(1+Q_y**2)+Q_yy*(1+Q_x**2)-2*Q_x*Q_y*Q_xy)/(1+Q_x**2 + Q_y**2)**(3/2)

        w = Q_Laplacian
        w_g = gradients(w, x)[0]
        w_t, w_x, w_y = w_g[:, 0], w_g[:, 1], w_g[:, 2]
        w_xx, w_xy, w_yy = gradients(w_x, x)[0][:, 1], \
                           gradients(w_x, x)[0][:, 2], gradients(w_y, x)[0][:, 2]

        w_Laplacian = (w_xx * (1 + w_y ** 2) + w_yy * (1 + w_x ** 2) - 2 * w_x * w_y * w_xy) / (
                    1 + w_x ** 2 + w_y ** 2) ** (3 / 2)

        loss_1 = u_t - w_Laplacian*torch.sqrt(u_x**2 + u_y**2 + 1)
        loss_2 = kappa - (u_xx*(1+u_y**2)+u_yy*(1+u_x**2)-2*u_x*u_y*u_xy)/(1+u_x**2 + u_y**2)**(3/2)
        loss_3 = Q_Laplacian - (Q_xx*(1+Q_y**2)+Q_yy*(1+Q_x**2)-2*Q_x*Q_y*Q_xy)/(1+Q_x**2 + Q_y**2)**(3/2)
        loss_4 = w_Laplacian - (w_xx * (1 + w_y ** 2) + w_yy * (1 + w_x ** 2) - 2 * w_x * w_y * w_xy) / (
                    1 + w_x ** 2 + w_y ** 2) ** (3 / 2)

        loss = (loss_1 ** 2).mean() + (loss_2 ** 2).mean() + \
               (loss_3 ** 2).mean() + (loss_4 ** 2).mean()
        return loss

    def loss_bc(self, x_l, x_r, x_up, x_dw):
        y_l, y_r, y_up, y_dw = self.net(x_l), self.net(x_r), self.net(x_up), self.net(x_dw)

        u_l = y_l[:, 0]
        u_r = y_r[:, 0]
        u_up = y_up[:, 0]
        u_dw = y_dw[:, 0]

        return ((u_l - u_r) ** 2).mean() +(u_up ** 2).mean() + (u_dw ** 2).mean()

    def loss_ic(self, x_i, u_i):
        y_pred = self.net(x_i)
        u_i_pred = y_pred[:, 0]
        # print(f'u_loss: {((u_i_pred-u_i)**2).mean():6f}')
        # print(f'v_loss: {((v_i_pred-v_i)**2).mean():6f}')
        # print(f'phi_loss: {((phi_i_pred-phi_i)**2).mean():6f}')
        return ((u_i_pred - u_i) ** 2).mean()


def AC_2D_init(x):
    ## bubble
    r = 0.2 * np.sqrt(2)
    a_x = -r / np.sqrt(2)
    a_y = r / np.sqrt(2)
    b_x = r / np.sqrt(2)
    b_y = -r / np.sqrt(2)
    u_init = 0.5 * np.tanh((-r + np.sqrt((x[:, 1] - a_x) ** 2 + (x[:, 2] - a_y) ** 2)) / 0.01 * 2 * np.sqrt(2)) + \
             0.5 * np.tanh((-r + np.sqrt((x[:, 1] - b_x) ** 2 + (x[:, 2] - b_y) ** 2)) / 0.01 * 2 * np.sqrt(2))
    return u_init

loss_history = {
    "loss_pde": [],
    "loss_ic": [],
    "loss_bc": [],
    "train_loss": []
}
def main():
    ## parameters
    device = torch.device(f"cuda:{1}" if torch.cuda.is_available() else "cpu")
    print(device)
    #device = torch.device("cpu")
    #print(device)
    epochs = 1000
    lr = 0.001

    num_x = 100
    num_y = 100
    num_t = 100
    num_b_train = 50  # boundary sampling points
    num_f_train = 50000  # inner sampling points
    num_i_train = 5000  # initial sampling points
    num_t_train = 40

    x = np.linspace(-1, 1, num=num_x)
    y = np.linspace(-1, 1, num=num_y)
    t = np.linspace(0, 5, num=num_t)[:, None]
    x_grid, y_grid = np.meshgrid(x, y)
    # x_test = np.concatenate((t_grid.flatten()[:,None], x_grid.flatten()[:,None], y_grid.flatten()[:,None]), axis=1)
    x_2d = np.concatenate((x_grid.flatten()[:, None], y_grid.flatten()[:, None]), axis=1)

    ## initialization
    xt_init = np.concatenate((np.zeros((num_x * num_y, 1)), x_2d), axis=1)
    u_init = AC_2D_init(xt_init)

    ## save init fig
    fig, ax = newfig(2.0, 1.1)
    ax.axis('off')
    gs0 = gridspec.GridSpec(1, 2)
    gs0.update(top=1 - 0.06, bottom=1 - 1 / 3, left=0.15, right=0.85, wspace=0)
    h = ax.imshow(u_init.reshape(num_x, num_y), interpolation='nearest', cmap='rainbow',
                  # extent=[t.min(), t.max(), x.min(), x.max()],
                  origin='lower', aspect='auto')
    fig.colorbar(h)
    ax.plot(xt_init[:, 1], xt_init[:, 2], 'kx', label='Data (%d points)' % (xt_init.shape[0]), markersize=4,
            clip_on=False)
    line = np.linspace(xt_init.min(), xt_init.max(), 2)[:, None]
    fig.savefig('Figures-1/u_init.png')

    x_2d_ext = np.tile(x_2d, [num_t, 1])
    t_ext = np.zeros((num_t * num_x * num_y, 1))
    for i in range(0, num_t):
        t_ext[i * num_x * num_y:(i + 1) * num_x * num_y, :] = t[i]
    xt_2d_ext = np.concatenate((t_ext, x_2d_ext), axis=1)

    ## sampling
    id_f = np.random.choice(num_x * num_y * num_t, num_f_train, replace=False)
    id_b = np.random.choice(num_x, num_b_train, replace=False)  ## Dirichlet
    id_i = np.random.choice(num_x * num_y, num_i_train, replace=False)
    id_t = np.random.choice(num_t, num_t_train, replace=False)

    ## boundary
    t_b = t[id_t, :]
    t_b_ext = np.zeros((num_t_train * num_b_train, 1))
    for i in range(0, num_t_train):
        t_b_ext[i * num_b_train:(i + 1) * num_b_train, :] = t_b[i]
    x_up = np.vstack((x_grid[-1, :], y_grid[-1, :])).T
    x_dw = np.vstack((x_grid[0, :], y_grid[0, :])).T
    x_l = np.vstack((x_grid[:, 0], y_grid[:, 0])).T
    x_r = np.vstack((x_grid[:, -1], y_grid[:, -1])).T
    # x_bound = np.vstack((x_up, x_dw, x_l, x_r))

    x_up_sample = x_up[id_b, :]
    x_dw_sample = x_dw[id_b, :]
    x_l_sample = x_l[id_b, :]
    x_r_sample = x_r[id_b, :]

    x_up_ext = np.tile(x_up_sample, (num_t_train, 1))
    x_dw_ext = np.tile(x_dw_sample, (num_t_train, 1))
    x_l_ext = np.tile(x_l_sample, (num_t_train, 1))
    x_r_ext = np.tile(x_r_sample, (num_t_train, 1))

    xt_up = np.hstack((t_b_ext, x_up_ext))
    xt_dw = np.hstack((t_b_ext, x_dw_ext))
    xt_l = np.hstack((t_b_ext, x_l_ext))
    xt_r = np.hstack((t_b_ext, x_r_ext))

    xt_i = xt_init[id_i, :]
    xt_f = xt_2d_ext[id_f, :]

    ## set data as tensor and send to device
    xt_f_train = torch.tensor(xt_f, requires_grad=True, dtype=torch.float32).to(device)
    # x_test = torch.tensor(xt_2d_ext, requires_grad=True, dtype=torch.float32).to(device)
    xt_i_train = torch.tensor(xt_init, requires_grad=True, dtype=torch.float32).to(device)
    x_i_train = torch.tensor(x_2d, requires_grad=True, dtype=torch.float32).to(device)

    u_i_train = torch.tensor(u_init, dtype=torch.float32).to(device)
    xt_l_train = torch.tensor(xt_l, requires_grad=True, dtype=torch.float32).to(device)
    xt_r_train = torch.tensor(xt_r, requires_grad=True, dtype=torch.float32).to(device)
    xt_up_train = torch.tensor(xt_up, requires_grad=True, dtype=torch.float32).to(device)
    xt_dw_train = torch.tensor(xt_dw, requires_grad=True, dtype=torch.float32).to(device)

    ## instantiate model
    model = DnCNN(channels=3).to(device)
    print(model)

    # Loss and optimizer
    optimizer = torch.optim.Adam(model.parameters(), lr = lr)

    # training
    train_loss = np.zeros((epochs, 1))
    def train(epoch):
        model.train()

        def closure():
            optimizer.zero_grad()
            loss_pde = model.loss_pde(xt_f_train)
            loss_bc = model.loss_bc(xt_l_train, xt_r_train, xt_up_train, xt_dw_train)
            loss_ic = model.loss_ic(xt_i_train, u_i_train)
            loss = loss_pde + loss_bc + 100 * loss_ic
            print(f'epoch {epoch} loss_pde:{loss_pde:6f}, loss_bc:{loss_bc:6f}, loss_ic:{loss_ic:6f}')
            loss_history["loss_pde"].append(loss_pde.item())
            loss_history["loss_bc"].append(loss_bc.item())
            loss_history["loss_ic"].append(loss_ic.item())
            train_loss[epoch, 0] = loss
            loss.backward()
            return loss

        loss = optimizer.step(closure)
        loss_value = loss.item() if not isinstance(loss, float) else loss
        print(f'epoch {epoch}: loss {loss_value:.6f}')
        loss_history["train_loss"].append(loss_value)
    print('start training...')
    tic = time.time()
    # for epoch in range(1, epochs + 1):
    for epoch in range(0, epochs):
        train(epoch)
        print(f'Train Epoch: {epoch + 1}, Train Loss: {train_loss[epoch, 0]:6f}', flush=True)
    toc = time.time()
    print(f'total training time: {toc - tic}')
    np.savetxt("Figures-1/train_loss_laplacian-CNN-condition-1.txt", train_loss)
    ##plot loss progress
    fig, ax = newfig(2.0, 1.1)
    # ax.axis('off')
    plt.title("loss")
    plt.plot(range(1, epochs + 1), loss_history["train_loss"], label="total loss", linewidth=3)
    plt.plot(range(1, epochs + 1), loss_history["loss_pde"], label="loss pde", linewidth=3)
    plt.plot(range(1, epochs + 1), loss_history["loss_ic"], label="loss ic", linewidth=3)
    plt.plot(range(1, epochs + 1), loss_history["loss_bc"], label="loss bc", linewidth=3)
    plt.ylabel("Loss", fontsize=22)
    plt.xlabel("Epochs", fontsize=22)
    plt.legend(fontsize=20)
    fig.savefig('Figures-1/Loss.png', dpi=300)
    fig.savefig('Figures-1/Loss.pdf')
    plt.show()
   ## test
    u_test = np.zeros((num_t, num_x, num_y))
    for i in range(0, num_t):
        xt = np.concatenate((t[i]*np.ones((num_x*num_y, 1)), x_2d), axis=1)
        xt_tensor = torch.tensor(xt, requires_grad=True, dtype=torch.float32).to(device)
        y_pred = model(xt_tensor)
        u_test[i,:,:] = to_numpy(y_pred[:, 0]).reshape(num_x, num_y)

        fig, ax = newfig(2.0, 1.1)
        ax.axis('off')
        gs0 = gridspec.GridSpec(1, 2)
        gs0.update(top=1-0.06, bottom=1-1/3, left=0.15, right=0.85, wspace=0)
        h = ax.imshow(u_test[i,:,:], interpolation='nearest', cmap='rainbow',
                # extent=[t.min(), t.max(), x.min(), x.max()],
                    origin='lower', aspect='auto')
        fig.colorbar(h)
        ax.plot(xt[:,1], xt[:,2], 'kx', label = 'Data (%d points)' % (xt.shape[0]), markersize = 4, clip_on = False)
        line = np.linspace(xt.min(), xt.max(), 2)[:,None]
        fig.savefig('Figures-1/u_'+str(i+1000)+'.png')

if __name__ == '__main__':
    main()
