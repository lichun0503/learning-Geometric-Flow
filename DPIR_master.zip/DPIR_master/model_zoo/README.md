
*  Google drive download link: [https://drive.google.com/drive/folders/13kfr3qny7S2xwG9h7v95F5mkWs0OmU0D?usp=sharing](https://drive.google.com/drive/folders/13kfr3qny7S2xwG9h7v95F5mkWs0OmU0D?usp=sharing)

*  腾讯微云下载链接: [https://share.weiyun.com/5qO32s3](https://share.weiyun.com/5qO32s3)


-----------------


|Model|Download link|Download link|
|---|:--:|:--:|
|drunet_gray.pth| [Google drive download link](https://drive.google.com/drive/folders/13kfr3qny7S2xwG9h7v95F5mkWs0OmU0D?usp=sharing) | [腾讯微云下载链接](https://share.weiyun.com/5qO32s3) |
|drunet_color.pth| [Google drive download link](https://drive.google.com/drive/folders/13kfr3qny7S2xwG9h7v95F5mkWs0OmU0D?usp=sharing) | [腾讯微云下载链接](https://share.weiyun.com/5qO32s3) |
|ircnn_gray.pth| [Google drive download link](https://drive.google.com/drive/folders/13kfr3qny7S2xwG9h7v95F5mkWs0OmU0D?usp=sharing) | [腾讯微云下载链接](https://share.weiyun.com/5qO32s3) |
|ircnn_color.pth| [Google drive download link](https://drive.google.com/drive/folders/13kfr3qny7S2xwG9h7v95F5mkWs0OmU0D?usp=sharing) | [腾讯微云下载链接](https://share.weiyun.com/5qO32s3) |
